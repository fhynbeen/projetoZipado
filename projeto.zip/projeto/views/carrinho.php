<html>
<head>
    <link rel="stylesheet" href="../semantic.css" type="text/css">
    <link rel="stylesheet" href="../css/estilo.css" type="text/css">
    <script type="text/javascript" src="../semantic.js"></script>
    <title >Compraki</title>
    <style>
        #menuzinho a:hover{
            background-color: #ff6a00;
        }
        body{

            ;
        }
        h1{
            font-weight: 100;
            line-height: 1.1;
        }
    </style>
    <script src="assets/library/jquery.min.js"></script>
    <script src="../dist/components/visibility.js"></script>
    <script src="../dist/components/sidebar.js"></script>
    <script src="../dist/components/transition.js"></script>
    <script>
        $(document)
            .ready(function() {

                // fix menu when passed
                $('.masthead')
                    .visibility({
                        once: false,
                        onBottomPassed: function() {
                            $('.fixed.menu').transition('fade in');
                        },
                        onBottomPassedReverse: function() {
                            $('.fixed.menu').transition('fade out');
                        }
                    })
                ;

                // create sidebar and attach to menu open
                $('.ui.sidebar')
                    .sidebar('attach events', '.toc.item')
                ;

            })
        ;
    </script>
</head>
<body>

<!-- Page Contents -->
<br><br>
<div class="pusher" >

    <div class="ui inverted vertical masthead center aligned segment" >

        <div class="ui text container" >
            <h1 class="ui inverted header">
                Carrinho
            </h1>
            <a href="produto.php"><div class="ui huge primary button">Adicionar mais produtos <i class="right arrow icon"></i></div></a>
        </div>


<div class="ui secondary pointing fixed hidden menu" style="background-color: #f4511e; display: flex !important; ">
    <a class="item" href="index.php">
        <p style="font-size: 20px; color: white;">Compraki</p>
    </a>
    <div id="menuzinho" class="right menu" style="background-color: #f4511e; padding-right: 40px; ">
        <a class="item">
            Home
        </a>
        <a class="active item">
            Carrinho
        </a>
        <a class="item" href="login.php">
            Login
        </a>
    </div>
</div>

<br><br><br><br><br><br>

<table class="ui compact celled definition table">
    <thead>
    <tr>
        <th></th>
        <th>Produto</th>
        <th>Quantidade</th>
        <th>Descrição</th>
        <th>Preço</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td class="collapsing">
            <div class="ui fitted slider checkbox">
                <input type="checkbox"> <label></label>
            </div>
        </td>
        <td>Arroz</td>
        <td>2un</td>
        <td>Arroz Parbonizado 5kg</td>
        <td>R$22,00</td>
    </tr>
    <tr>
        <td class="collapsing">
            <div class="ui fitted slider checkbox">
                <input type="checkbox"> <label></label>
            </div>
        </td>
        <td>Feijão</td>
        <td>1un</td>
        <td>Feijão Preto 1kg</td>
        <td>R$6,74</td>
    </tr>
    <tr>
        <td class="collapsing">
            <div class="ui fitted slider checkbox">
                <input type="checkbox"> <label></label>
            </div>
        </td>
        <td>Macarrão</td>
        <td>2un</td>
        <td>Macarrão tipo Espaguete</td>
        <td>R$8,87</td>
    </tr>
    </tbody>
    <tfoot class="full-width">
    <tr>
        <th></th>
        <th colspan="4">
            <a href="pagamento.php">
            <div class="ui right floated small primary labeled icon button">
                <i class="shopping cart icon"></i>Comprar
            </div>
            </a>
         <h4>
             Valor total: R$37,61
         </h4>

        </th>
    </tr>
    </tfoot>
</table>