<?php

$json = file_get_contents('data_bases/produtos.json');
$array_produtos = json_decode($json, true);
?>
<!DOCTYPE html>
    <html lang="en">
        <title>CompreAki</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="../semantic.css" type="text/css">
        <link rel="stylesheet" href="../css/estilo.css" type="text/css">
        <script type="text/javascript" src="../semantic.js"></script>
<body>
<div class="ui secondary pointing fixed hidden menu" style="background-color: #f4511e; display: flex !important; ">
        <a class="item" href="index.php">
            <p style="font-size: 20px; color: white;">Compraki</p>
        </a>
        <div id="menuzinho" class="right menu" style="background-color: #f4511e; padding-right: 40px; ">
            <a class="active item" style="color: white; border-color: white;">
                Home
            </a>
            <a class="item" style="color: white;">
                Carrinho
            </a>
            <a class="item" href="login.php" style="color: white;">
                Login
            </a>
        </div>
    </div>
    <br>
    <br><br><br><br>

<div class="ui link cards" id="cards"><?php foreach($array_produtos as $produto): ?>
    <div class="card" id="cardsJogos">
        <div class="image">
            <img src="data_bases/img/<?= $produto['img'] ?>" style="width: 200px; height: 230px;">
        </div>
        <div class="content" >
            <div class="description">
                <?= $produto['desc'] ?>
            </div>
        </div>
        <div class="extra content">
      <span class="right floated" style="padding-right: 20px">

      </span>
            <span>
        <?= $produto['preco'] ?><i class="tag up icon blue" style="color-text: black; padding-left: 200px;"></i>
      </span>
        </div>
    </div>
<?php endforeach ?>
</div>

</body>
</html>
